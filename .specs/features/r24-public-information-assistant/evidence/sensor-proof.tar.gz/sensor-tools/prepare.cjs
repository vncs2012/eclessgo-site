const fs = require("node:fs");
const path = require("node:path");

const ARTIFACT_ROOT = "/home/vncs/.codex/visualizations/2026/10/20/01a15a26-0a0f-7bb3-998f-477d09b1e28d/r24";
const SOURCE_ROOT = path.join(ARTIFACT_ROOT, "index-candidates");
const SCRATCH_ROOT = path.join(ARTIFACT_ROOT, "scratch-active");
const PROOF_ROOT = path.join(ARTIFACT_ROOT, "sensor-proof");

const SOURCE_FILES = Object.freeze([
  "src/lib/public-information-assistant.ts",
  "src/lib/public-information-assistant-provider.ts",
  "src/app/api/public/churches/slug/[slug]/assistant/route.ts",
  "src/components/site/public-information-assistant.tsx",
  "src/app/igrejas/[slug]/page.tsx",
  "src/app/comunidades/[slug]/page.tsx",
  "src/messages/pt-BR.json",
  "src/messages/en.json",
]);

const VARIANTS = Object.freeze([
  Object.freeze({
    id: "Q1",
    file: "src/lib/public-information-assistant.ts",
    old: 'addFact("description", labels.description, boundedPublicText(source.description));',
    replacement: 'addFact("description", labels.description, boundedPublicText(source.pixKey));',
    witness: "tests/r24/core.test.cjs:93",
    violation: "INFO-02: replace a published description fact with a private donation field",
    specIds: ["INFO-02"],
    expected: "The literal projection assertion fails because the public description is replaced by the private fixture marker.",
  }),
  Object.freeze({
    id: "Q2",
    file: "src/lib/public-information-assistant.ts",
    old: "sources: selectedFacts.map((fact) => ({ factId: fact.id, href: SOURCE_PATH(slug) })),",
    replacement: 'sources: selectedFacts.map((fact) => ({ factId: fact.id, href: SOURCE_PATH("outra-comunidade") })),',
    witness: "tests/r24/core.test.cjs:162",
    violation: "INFO-03: return citations for a different community",
    specIds: ["INFO-03"],
    expected: "The exact anchored response assertion fails because every source points to a different community.",
  }),
  Object.freeze({
    id: "Q3",
    file: "src/lib/public-information-assistant.ts",
    old: 'if (typeof factId !== "string" || seen.has(factId)) return null;',
    replacement: 'if (typeof factId !== "string") return null;',
    witness: "tests/r24/core.test.cjs:264",
    violation: "INFO-05: accept duplicate selected fact IDs",
    specIds: ["INFO-05"],
    expected: "The duplicate-ID case returns a successful response instead of the asserted 502 error.",
  }),
  Object.freeze({
    id: "Q4",
    file: "src/lib/public-information-assistant.ts",
    old: "if (!question || [...question].length > QUESTION_LIMIT_CODE_POINTS) return null;",
    replacement: "if (!question || [...question].length >= QUESTION_LIMIT_CODE_POINTS) return null;",
    witness: "tests/r24/core.test.cjs:386",
    violation: "INFO-08: reject the inclusive 500-code-point question boundary",
    specIds: ["INFO-08"],
    expected: "The 500-code-point request receives 400 instead of the asserted 200.",
  }),
  Object.freeze({
    id: "Q5",
    file: "src/lib/public-information-assistant.ts",
    old: "        controller.abort();",
    replacement: "        void controller;",
    witness: "tests/r24/core.test.cjs:325",
    violation: "INFO-07: leave the adapter signal active after timeout",
    specIds: ["INFO-07"],
    expected: "The timeout assertion observes an unaborted adapter signal while the handler still returns 504.",
  }),
  Object.freeze({
    id: "Q6",
    file: "src/app/api/public/churches/slug/[slug]/assistant/route.ts",
    old: 'return await getPublicChurchBySlug(slug, { cache: "no-store" });',
    replacement: 'return await getPublicChurchBySlug(slug, { cache: "force-cache" });',
    witness: "tests/r24/route.test.cjs:109",
    violation: "INFO-01: cache the current public community read",
    specIds: ["INFO-01"],
    expected: "The exact reader-arguments assertion observes force-cache instead of no-store.",
  }),
  Object.freeze({
    id: "Q7",
    file: "src/components/site/public-information-assistant.tsx",
    old: "if (item.href !== expectedHref) return null;",
    replacement: "void item.href;",
    witness: "tests/r24/ui.test.cjs:349",
    violation: "INFO-13: accept a response carrying a noncanonical community citation",
    specIds: ["INFO-13"],
    expected: "The invalid-source case displays a conversation instead of the asserted absent conversation.",
  }),
  Object.freeze({
    id: "Q8",
    file: "src/components/site/public-information-assistant.tsx",
    old: "requestControllerRef.current?.abort();",
    replacement: "void requestControllerRef.current;",
    witness: "tests/r24/ui.test.cjs:394,418,444",
    violation: "INFO-14: do not abort active requests on context change or unmount",
    specIds: ["INFO-14"],
    expected: "The context and unmount assertions observe a signal that was not aborted.",
  }),
]);

function assertNoSymlinkPath(absolutePath, { includeLeaf = true } = {}) {
  const resolved = path.resolve(absolutePath);
  const parsed = path.parse(resolved);
  const segments = resolved.slice(parsed.root.length).split(path.sep).filter(Boolean);
  let current = parsed.root;
  const lastIndex = includeLeaf ? segments.length : Math.max(segments.length - 1, 0);

  for (let index = 0; index < lastIndex; index += 1) {
    current = path.join(current, segments[index]);
    let stats;
    try {
      stats = fs.lstatSync(current);
    } catch (error) {
      if (error && error.code === "ENOENT") return;
      throw error;
    }
    if (stats.isSymbolicLink()) throw new Error(`Symlink path is refused: ${current}`);
  }
}

function countOccurrences(text, search) {
  let count = 0;
  let offset = 0;
  while (true) {
    const foundAt = text.indexOf(search, offset);
    if (foundAt === -1) return count;
    count += 1;
    offset = foundAt + search.length;
  }
}

function ensureDirectory(directoryPath) {
  assertNoSymlinkPath(directoryPath);
  fs.mkdirSync(directoryPath, { recursive: true });
  const stats = fs.lstatSync(directoryPath);
  if (stats.isSymbolicLink() || !stats.isDirectory()) {
    throw new Error(`Expected a regular directory: ${directoryPath}`);
  }
}

function writeSourceTree(root, sourceBytes, override) {
  fs.mkdirSync(root, { recursive: false });
  for (const relativePath of SOURCE_FILES) {
    const destination = path.join(root, relativePath);
    ensureDirectory(path.dirname(destination));
    const contents = relativePath === override?.file
      ? Buffer.from(override.text, "utf8")
      : sourceBytes.get(relativePath);
    fs.writeFileSync(destination, contents, { flag: "wx" });
  }
}

function unifiedSingleLineDiff(relativePath, original, mutation) {
  const offset = original.indexOf(mutation.old);
  const lineStart = original.lastIndexOf("\n", offset) + 1;
  const lineEndIndex = original.indexOf("\n", offset);
  const lineEnd = lineEndIndex === -1 ? original.length : lineEndIndex;
  const oldLine = original.slice(lineStart, lineEnd).replace(/\r$/, "");
  const newLine = oldLine.replace(mutation.old, mutation.replacement);
  const lineNumber = original.slice(0, lineStart).split("\n").length;
  return [
    `--- a/${relativePath}`,
    `+++ b/${relativePath}`,
    `@@ -${lineNumber},1 +${lineNumber},1 @@`,
    `-${oldLine}`,
    `+${newLine}`,
    "",
  ].join("\n");
}

function assertProofDestinationsAvailable() {
  assertNoSymlinkPath(PROOF_ROOT, { includeLeaf: false });
  try {
    const stats = fs.lstatSync(PROOF_ROOT);
    if (stats.isSymbolicLink() || !stats.isDirectory()) {
      throw new Error("The sensor-proof destination must be a regular directory");
    }
    for (const name of ["manifest.json", ...VARIANTS.map((variant) => `${variant.id}.diff`)]) {
      try {
        fs.lstatSync(path.join(PROOF_ROOT, name));
        throw new Error(`Refusing to overwrite sensor proof: ${name}`);
      } catch (error) {
        if (!error || error.code !== "ENOENT") throw error;
      }
    }
  } catch (error) {
    if (!error || error.code !== "ENOENT") throw error;
  }
}

function main() {
  if (path.resolve(SOURCE_ROOT) !== path.join(ARTIFACT_ROOT, "index-candidates")) {
    throw new Error("The frozen source root changed unexpectedly");
  }
  assertNoSymlinkPath(SOURCE_ROOT);
  assertNoSymlinkPath(SCRATCH_ROOT, { includeLeaf: false });
  try {
    fs.lstatSync(SCRATCH_ROOT);
    throw new Error("Refusing to overwrite scratch-active");
  } catch (error) {
    if (!error || error.code !== "ENOENT") throw error;
  }
  assertProofDestinationsAvailable();

  const sourceBytes = new Map();
  const sourceText = new Map();
  for (const relativePath of SOURCE_FILES) {
    const sourcePath = path.join(SOURCE_ROOT, relativePath);
    assertNoSymlinkPath(sourcePath);
    const stats = fs.lstatSync(sourcePath);
    if (stats.isSymbolicLink() || !stats.isFile()) {
      throw new Error(`Expected a regular whitelisted source file: ${relativePath}`);
    }
    const bytes = fs.readFileSync(sourcePath);
    sourceBytes.set(relativePath, bytes);
    sourceText.set(relativePath, bytes.toString("utf8"));
  }

  const prepared = VARIANTS.map((variant) => {
    const original = sourceText.get(variant.file);
    if (countOccurrences(original, variant.old) !== 1) {
      throw new Error(`${variant.id} must replace exactly one frozen source literal`);
    }
    const mutated = original.replace(variant.old, variant.replacement);
    if (mutated === original || countOccurrences(mutated, variant.replacement) < 1) {
      throw new Error(`${variant.id} did not produce its sole prescribed change`);
    }
    return { ...variant, text: mutated, diff: unifiedSingleLineDiff(variant.file, original, variant) };
  });

  fs.mkdirSync(SCRATCH_ROOT, { recursive: false });
  writeSourceTree(path.join(SCRATCH_ROOT, "control"), sourceBytes);
  for (const variant of prepared) {
    writeSourceTree(path.join(SCRATCH_ROOT, variant.id), sourceBytes, variant);
  }

  ensureDirectory(PROOF_ROOT);
  const manifest = {
    format: "R24 local sensor variants v1",
    sourcePack: "index-candidates",
    control: "scratch-active/control",
    sourceFiles: SOURCE_FILES,
    variants: prepared.map(({ id, file, old, replacement, witness, violation, specIds, expected }) => ({
      id,
      path: file,
      old,
      new: replacement,
      witness,
      violation,
      specIds,
      expected,
      replacementCount: 1,
      scratch: `scratch-active/${id}`,
      diff: `${id}.diff`,
    })),
  };
  fs.writeFileSync(path.join(PROOF_ROOT, "manifest.json"), `${JSON.stringify(manifest, null, 2)}\n`, { flag: "wx" });
  for (const variant of prepared) {
    fs.writeFileSync(path.join(PROOF_ROOT, `${variant.id}.diff`), variant.diff, { flag: "wx" });
  }
}

main();
