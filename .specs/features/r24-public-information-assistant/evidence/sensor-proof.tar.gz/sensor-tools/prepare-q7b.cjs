const fs = require("node:fs");
const path = require("node:path");

const ARTIFACT_ROOT = "/home/vncs/.codex/visualizations/2026/10/20/01a15a26-0a0f-7bb3-998f-477d09b1e28d/r24";
const SCRATCH_ROOT = path.join(ARTIFACT_ROOT, "scratch-active");
const CONTROL_ROOT = path.join(SCRATCH_ROOT, "control");
const VARIANT_ROOT = path.join(SCRATCH_ROOT, "Q7b");
const PROOF_ROOT = path.join(ARTIFACT_ROOT, "sensor-proof");

const SOURCE_FILES = Object.freeze([
  "src/lib/public-information-assistant.ts",
  "src/lib/public-information-assistant-provider.ts",
  "src/app/api/public/churches/slug/[slug]/assistant/route.ts",
  "src/components/site/public-information-assistant.tsx",
  "src/app/igrejas/[slug]/page.tsx",
  "src/app/comunidades/[slug]/page.tsx",
  "src/messages/pt-BR.json",
  "src/messages/en.json",
]);

const COMPONENT_PATH = "src/components/site/public-information-assistant.tsx";
const OLD_LITERAL = "const expectedHref = `/comunidades/${slug}`;";
const NEW_LITERAL = "const expectedHref = `/comunidades/${slug}/`;";

function assertNoSymlinkPath(absolutePath, { includeLeaf = true } = {}) {
  const resolved = path.resolve(absolutePath);
  const parsed = path.parse(resolved);
  const segments = resolved.slice(parsed.root.length).split(path.sep).filter(Boolean);
  let current = parsed.root;
  const lastIndex = includeLeaf ? segments.length : Math.max(segments.length - 1, 0);

  for (let index = 0; index < lastIndex; index += 1) {
    current = path.join(current, segments[index]);
    let stats;
    try {
      stats = fs.lstatSync(current);
    } catch (error) {
      if (error && error.code === "ENOENT") return;
      throw error;
    }
    if (stats.isSymbolicLink()) throw new Error(`Symlink path is refused: ${current}`);
  }
}

function countOccurrences(text, search) {
  let count = 0;
  let offset = 0;
  while (true) {
    const foundAt = text.indexOf(search, offset);
    if (foundAt === -1) return count;
    count += 1;
    offset = foundAt + search.length;
  }
}

function ensureDirectory(directoryPath) {
  assertNoSymlinkPath(directoryPath);
  fs.mkdirSync(directoryPath, { recursive: true });
  const stats = fs.lstatSync(directoryPath);
  if (stats.isSymbolicLink() || !stats.isDirectory()) {
    throw new Error(`Expected a regular directory: ${directoryPath}`);
  }
}

function assertAbsent(targetPath, description) {
  try {
    fs.lstatSync(targetPath);
    throw new Error(`Refusing to overwrite ${description}`);
  } catch (error) {
    if (!error || error.code !== "ENOENT") throw error;
  }
}

function writeTree(sourceBytes, componentText) {
  fs.mkdirSync(VARIANT_ROOT, { recursive: false });
  for (const relativePath of SOURCE_FILES) {
    const destination = path.join(VARIANT_ROOT, relativePath);
    ensureDirectory(path.dirname(destination));
    const contents = relativePath === COMPONENT_PATH
      ? Buffer.from(componentText, "utf8")
      : sourceBytes.get(relativePath);
    fs.writeFileSync(destination, contents, { flag: "wx" });
  }
}

function makeDiff(originalText) {
  const offset = originalText.indexOf(OLD_LITERAL);
  const lineStart = originalText.lastIndexOf("\n", offset) + 1;
  const lineEndIndex = originalText.indexOf("\n", offset);
  const lineEnd = lineEndIndex === -1 ? originalText.length : lineEndIndex;
  const oldLine = originalText.slice(lineStart, lineEnd).replace(/\r$/, "");
  const newLine = oldLine.replace(OLD_LITERAL, NEW_LITERAL);
  const lineNumber = originalText.slice(0, lineStart).split("\n").length;

  return [
    `--- a/${COMPONENT_PATH}`,
    `+++ b/${COMPONENT_PATH}`,
    `@@ -${lineNumber},1 +${lineNumber},1 @@`,
    `-${oldLine}`,
    `+${newLine}`,
    "",
  ].join("\n");
}

function main() {
  if (path.resolve(CONTROL_ROOT) !== path.join(ARTIFACT_ROOT, "scratch-active", "control")) {
    throw new Error("The frozen control root changed unexpectedly");
  }
  assertNoSymlinkPath(CONTROL_ROOT);
  assertNoSymlinkPath(VARIANT_ROOT, { includeLeaf: false });
  assertAbsent(VARIANT_ROOT, "scratch-active/Q7b");
  ensureDirectory(PROOF_ROOT);
  const diffPath = path.join(PROOF_ROOT, "Q7b.diff");
  const manifestPath = path.join(PROOF_ROOT, "Q7b.json");
  assertNoSymlinkPath(diffPath, { includeLeaf: false });
  assertNoSymlinkPath(manifestPath, { includeLeaf: false });
  assertAbsent(diffPath, "sensor-proof/Q7b.diff");
  assertAbsent(manifestPath, "sensor-proof/Q7b.json");

  const sourceBytes = new Map();
  for (const relativePath of SOURCE_FILES) {
    const sourcePath = path.join(CONTROL_ROOT, relativePath);
    assertNoSymlinkPath(sourcePath);
    const stats = fs.lstatSync(sourcePath);
    if (stats.isSymbolicLink() || !stats.isFile()) {
      throw new Error(`Expected a regular control source: ${relativePath}`);
    }
    sourceBytes.set(relativePath, fs.readFileSync(sourcePath));
  }

  const componentText = sourceBytes.get(COMPONENT_PATH).toString("utf8");
  if (countOccurrences(componentText, OLD_LITERAL) !== 1) {
    throw new Error("Q7b must replace exactly one frozen source literal");
  }
  const mutatedText = componentText.replace(OLD_LITERAL, NEW_LITERAL);
  if (mutatedText === componentText || countOccurrences(mutatedText, NEW_LITERAL) < 1) {
    throw new Error("Q7b did not produce its sole prescribed change");
  }
  const diff = makeDiff(componentText);

  writeTree(sourceBytes, mutatedText);
  const manifest = {
    id: "Q7b",
    path: COMPONENT_PATH,
    old: OLD_LITERAL,
    new: NEW_LITERAL,
    witness: "tests/r24/ui.test.cjs:264",
    violation: "INFO-12: reject a valid answer because its canonical citation omits a trailing slash",
    specIds: ["INFO-12"],
    replacementCount: 1,
    source: "scratch-active/control",
    variant: "scratch-active/Q7b",
    diff: "Q7b.diff",
    expected: "A valid answer is refused because its canonical citation has no trailing slash; the witness boolean is false instead of true.",
  };
  fs.writeFileSync(diffPath, diff, { flag: "wx" });
  fs.writeFileSync(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, { flag: "wx" });
}

main();
