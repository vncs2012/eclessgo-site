export const publicInformationAssistantProvider = null;
